rm -r /var/task/*
rm -r /tmp/*
cd /var/sharp
rm -r nodejs lib