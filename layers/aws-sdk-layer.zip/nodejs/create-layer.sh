# !/bin/bash

yum install -y gcc-c++ make
curl -sL https://rpm.nodesource.com/setup_20.x | bash -
yum install -y nodejs zip

mkdir /var/task
cd /var/task

npm install aws-sdk

cd /tmp
mkdir nodejs
cd nodejs
cp -r /var/task/* .

cd ..
zip -r aws-sdk-layer.zip nodejs